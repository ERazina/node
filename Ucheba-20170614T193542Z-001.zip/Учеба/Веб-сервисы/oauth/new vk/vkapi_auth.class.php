<?php
class VKPublic
{
    protected $groupId, $userId, $appId, $secretKey, $accessToken, $accessSecret; 
    /**
     * @param int $groupId
     * @param int $appId
     * @param string $secretKey
     */
    public function __construct($groupId, $userId, $appId, $secretKey)
    {
		global $db;
        $this->groupId = $groupId;
		$this->userId = $userId;
        $this->appId = $appId;
        $this->secretKey = $secretKey;
		if(isset($db)){$this->connection=$db;};
		
    } 
 	
    /**
     * @param string $accessToken
     * @param string $accessSecret
     */
    public function setAccessData($accessToken, $accessSecret)
    {
        $this->accessToken = $accessToken;
        $this->accessSecret = $accessSecret;//используется для создания подписи запроса sig
    } 

    public function getAccessData()
    {
		
		$url = 'http://oauth.vk.com/authorize';
		$redirect_uri_blank='https://oauth.vk.com/blank.html';
    	$params = array(
        'client_id' => $this->appId,
		'scope'=>'offline,ads,wall,groups,pages,photos,status,friends,docs,audio,video,notes,stats,notify,messages,notifications,nohttps',
        'redirect_uri'  => $redirect_uri_blank,//для получения специального токена нужно использовать такую ссылку
        'response_type' => 'code'
    	);
		
		echo"<!doctype html><html><head><meta charset='utf-8'></head><body>";
		echo $link = '<a href="'.$url.'?'.urldecode(http_build_query($params)).' " target="_blank">Аутентификация через ВКонтакте</a>';
		echo '</body></html>';

		$url_token='https://oauth.vk.com/access_token';
   		$params = array(
        'client_id' => $this->appId,
		'client_secret'=>$this->secretKey,
		'redirect_uri'=>$redirect_uri_blank,
        'code' =>'');
		echo '<br>Код для <strong>токена</strong> генерируется по нажатой ссылке, она откроется в <strong>соседнем окне</strong>.';
		echo '<br>Код копируем из строки браузера!!!!';
		?><form action="" method="get">
        <input type="text" name="code">
        <input type="submit" value="получить токен">
        </form>
		<?php
		if (isset($_GET['code'])) {
			 $params = array(
        'client_id' => $this->appId,
		'client_secret'=>$this->secretKey,
		'redirect_uri'=>$redirect_uri_blank,
        'code' =>$_GET['code']);
		unset($_GET['code']);
			 $token = json_decode(file_get_contents($url_token.'?'.urldecode(http_build_query($params))), true);
			}
	 
 	if (isset($token['access_token'],$token['secret'])) {
		$qins="UPDATE pandora SET pandora_access_token = '".$token['access_token']."',pandora_access_secret='".$token['secret']."' WHERE pandora_app_id =".$this->appId;
		if($this->connection->query($qins)){
			echo "Токены обновлены";
			}
	//print_r($token);
	}
} 
    /**
     * @param string $method
     * @param mixed $parameters
     * @return mixed
     */
    public function callMethod($method, $parameters)
    {
        if (!$this->accessToken) return false;
        if (is_array($parameters)) $parameters = http_build_query($parameters);
        $queryString = "/method/$method?$parameters&access_token={$this->accessToken}";
        $querySig = md5($queryString . $this->accessSecret);//создание подписи запроса sig
        return json_decode(file_get_contents(
            "http://api.vk.com{$queryString}&sig=$querySig"
        ));
    } 
 
    
}

?>