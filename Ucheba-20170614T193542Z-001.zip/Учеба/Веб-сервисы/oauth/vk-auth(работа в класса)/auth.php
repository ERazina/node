<?php
class VK {
    
    protected static $client_id='5683896';
    protected static $secret_key='R40ZkFwjTizuBZgYkUjl';
    protected static $uri='http://localhost/vk-auth';
    protected static $code;
    protected $token;
    protected $userId;
    protected $userInfo;

    
    public function __construct($code) {
        $this->ccode=$code;
        $this->getToken();
        $this->getInfo();
    }
    public function getToken() {
          $params = array(
            'client_id'     => $this->client_id,
            'client_secret' => $this->secret_key,
            'code'          => $this->code,
            'redirect_uri'  => $this->uri,
        );
        
        $info = json_decode(file_get_contents('https://oauth.vk.com/access_token' . '?' . urldecode(http_build_query($params))), true);
        $this->token=info['access_token'];
        $this->userId=info['user_id'];

    }
    //получение информации о пользователе
    
    public function getInfo() {
        $params = array(
            'uid'         => $this->uid,
            'fields'       => 'uid,first_name,last_name,screen_name,sex,bdate,photo_big',
            'access_token' => $this->token,
//            
//            'first_name'  => $this->first_name,
//            'last_name'   => $this->last_name,
//            'screen_name' => $this->screen_name,
//            'sex'         => $this->sex,
//            'bdate'       => $this->bdate,
//            'photo_big'   => $this->photo_big,
            
        );

        $this->userInfo = json_decode(file_get_contents('https://api.vk.com/method/users.get' . '?' . urldecode(http_build_query($params))), true);
        }
    public static function showLink() {
        $params = array(
            'client_id'     => self::$client_id,
            'redirect_uri'  => self::$uri,
            'response_type' => self::$code,
            );
        $url = 'http://oauth.vk.com/authorize';
        echo $link = '<p><a href="' . $url . '?' . urldecode(http_build_query($params)) . '">Аутентификация через ВКонтакте</a></p>';
    }
}
VK::showLink();

?>