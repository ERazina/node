<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Document</title>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

  <script defer="defer" src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <script defer="defer" src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
  <script defer="defer" src="handlebars-latest.js"></script>
  <script defer="defer" src="https://cdn.jsdelivr.net/lodash/4.17.2/lodash.min.js"></script>
  <script defer="defer" src="script.js"></script>
</head>
<body>
<header>Films </header>
<form id="filter-form">
  Date<input name="date" type="date" class="js-date"/>
  Movie<select name="movie" class="js-select-movie">
      </select>
  Genre<select name="genre" class="js-select-genre">
      </select>
  Time<input name="start_time" type="time" class="js-time-start"/> - <input name="end_time" type="time" class="js-time-end"/>
  Price<select name="price" class="js-select-price">
      </select>
</form>
<div id="root"></div>
<?php
include_once "modals.php";
 ?>
</body>
</html>
