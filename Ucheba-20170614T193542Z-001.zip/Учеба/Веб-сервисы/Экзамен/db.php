<?php

define('HOST', 'localhost');
define('USER', 'root');
define('PASS', '');
define('DB',   'cinema');


function get($query){
  $connect = mysqli_connect(HOST, USER, PASS, DB);
  mysqli_set_charset($connect, 'UTF8');
  $res = mysqli_query($connect, $query);
  $array = array();
  while($obj = mysqli_fetch_object($res)) {
    $array[] = $obj;
  }
  return $array;
}
function escape($val) {
  $connect = mysqli_connect(HOST, USER, PASS, DB);
  mysqli_set_charset($connect, 'UTF8');
  return mysqli_real_escape_string($connect, $val);
}

function insert($table, $values) {
  $connect = mysqli_connect(HOST, USER, PASS, DB);
  mysqli_set_charset($connect, 'UTF8');
  $cols = '';
  $vals = '';
  foreach ($values as $column => $value) {
    $cols.= "`" . escape($column) . "`,";
    $vals.= "'" . escape($value) . "',";
  }
  $cols  = trim($cols, ',');
  $vals  = trim($vals, ',');

  $query = "INSERT INTO `" . escape($table) . "` ($cols) VALUE($vals);";
  mysqli_query($connect, $query);
  return mysqli_insert_id($connect);
  }

?>
