<?php
header('Content-Type: application/json');
include_once('db.php');
echo json_encode(query($_REQUEST));

function query($data){
  $query="SELECT `seance`.`ID` AS `seance_id`,
    `movies`.`ID` AS `movie_id`,
    `movies`.`name` AS `movie_name`,
    `genre`.`name` AS `genre_name`,
    `genre`.`ID` AS `genre_id`,
    `seance`.`price`,
    `seance`.`datetime`,
    `movies`.`desc`
    FROM `seance`
    LEFT JOIN `movies` ON(`movies`.`ID`=`seance`.`ID_movie`)
    LEFT JOIN `genre` ON(`genre`.`ID`=`movies`.`ID_genre`)
    WHERE 1";

  foreach ($data as $item => $value) {
    switch ($item) {
      case 'date':
        $date=$value;
        $start_time=!empty($data['start_time']) ? $data['start_time'] : '00:00:00';
        $end_time=!empty($data['end_time']) ? $data['end_time'] : '23:59:59';

        $query .= buildDateTime($date, $start_time, $end_time);
        break;

        case 'movie':
          $movie=$value;
          $query .= buildMovie($movie);
          break;

        case 'genre':
          $genre=$value;
          $query .= buildGenre($genre);
          break;

        case 'price':
          $price=$value;
          $query .= buildPrice($price);
          break;
    }
  }

  return get($query);
}

function buildDateTime($date='2016-11-24', $start_time='00:00:00', $end_time='23:59:59') {
  return " AND `seance`.`datetime`>'$date $start_time' AND `seance`.`datetime`<'$date $end_time'";
}

function buildMovie($movie) {
  return " AND `movies`.`ID`='$movie'";
}

function buildGenre($genre){
  return " AND `genre`.`ID`='$genre'";
}

function buildPrice($price){
  return " AND `seance`.`price`='$price'";
}



// SELECT * FROM `seance`
// LEFT JOIN `movies` ON(`movies`.`ID`=`seance`.`ID_movie`)
// LEFT JOIN `genre` ON(`genre`.`ID`=`movies`.`ID_genre`)
// WHERE
// .buildDateTime('2016-11-24', '17:00:00', '23:00:00').
// AND `movies`.`ID`='1'
// AND `genre`.`ID`='1'
// AND `seance`.`price`='380'
?>
