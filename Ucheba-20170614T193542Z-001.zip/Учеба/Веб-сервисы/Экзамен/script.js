$.ajaxSetup({
  dataType: 'json',
  contentType: 'application/json',
})

$(function() {
  $('.js-date').on('change', function(){
    request('api.php', buildData(), render.bind(null, 'date'))
  })
  $('.js-select-movie').on('change', function(){
    request('api.php', buildData(), render.bind(null, 'movie'))
  })
  $('.js-select-genre').on('change', function(){
    request('api.php', buildData(), render.bind(null, 'genre'))
  })
  $('.js-time-start').on('change', function(){
    request('api.php', buildData(), render.bind(null, 'start_time'))
  })
  $('.js-time-end').on('change', function(){
    request('api.php', buildData(), render.bind(null, 'end_time'))
  })
  $('.js-select-price').on('change', function(){
    request('api.php', buildData(), render.bind(null, 'price'))
  })
})

// Functions
function buildData() {
  return $('#filter-form').serializeArray()
    .filter(function(item){
      return !!item.value
    })
    .map(function(item){
      return item.name+'='+item.value+'&'
    })
    .join('')
}
function request(url, data, callback, post) {
  $.ajax({
    url:url,
    data: data,
    method: post ? 'POST' : 'GET',
  })
  .done(callback)
  .fail(showError)
}

function showError(error) {
  console.error(error)
}

function render(field, res) {
  var movies = res.map(function(item){
    return '<option value="'+item.movie_id+'">'+item.movie_name+'</option>'
  })
  movies = _.uniq(movies)
  movies = '<option disabled selected>-</option>'+movies.join('')
  $('.js-select-movie').html(movies)

  if (field !== 'genre') {
    var genre = res.map(function(item){
      return '<option value="'+item.genre_id+'">'+item.genre_name+'</option>'
    })
    genre = _.uniq(genre)
    var genre_addition = genre.length > 1 ? '<option disabled selected>-</option>' : ''
    genre = genre_addition+genre.join('')
    $('.js-select-genre').html(genre)
  }

  var price = res.map(function(item){
    return '<option value="'+item.price+'">'+item.price+'</option>'
  })
  price = price.sort()
  price = _.sortedUniq(price)
  price = '<option disabled selected>-</option>'+price.join('')
  $('.js-select-price').html(price)

  var seances = res.map(function(item){
    return '<div><h4>'+item.movie_name+'</h4><p>'+item.genre_name+'</p><p>'+item.datetime+'</p><p>'+item.price+'</p><p>'+item.desc+'</p></div>'
  })
  seances = seances.join('')
  $('#root').html(seances)

}
