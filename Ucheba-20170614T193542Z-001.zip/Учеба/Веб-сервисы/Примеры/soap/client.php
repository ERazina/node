﻿<?php
	// создаем soap клиент. ссылку делаем на wsdl. Именно оттуда мы получим описание доступных функций, переменных и их типов.	
	$client = new SoapClient("http://localhost/soap/server.wsdl");
	$users  = json_decode($client->getUser());
	echo '<pre>';
	print_r($users);
	echo '<pre>';
?>