<?php
	//sleep(5);
	echo "<p>Привет {$_POST['name']}! Вам {$_POST['age']}</p>";
	
?>