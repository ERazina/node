<?php
	$method = $_SERVER['REQUEST_METHOD'];
	switch ($method) {
		case 'GET': 
			show();
			break;
		case 'POST': 
			insert();
			break;
		case 'PUT': 
			update($id);
			break;
		case 'DELETE': 
			delete($id);
			break;
		default:
			echo 'Использован некорректный метод';
	}
	
	function show() {
		$arr = json_encode(array('code' => '200', 'text' => 'Все хорошо'));
		echo $arr;
	}
	
	function insert() {
		$data = (array)json_decode($_REQUEST['data']);
		echo "Добавлена новая запись:<br>
			Имя: <b>{$data['name']}</b><br>
			Описание: <b>{$data['desc']}</b><br>
			Новый ID: <b>23</b>
		";
	}
	
	function update($id) {
		$data = (array)json_decode(file_get_contents('php://input'));
		echo "Запись №$id отредактирована<br>
			Новое имя: <b>{$data['name']}</b><br>
			Новое описание: <b>{$data['desc']}</b><br>
		";
	}
	
	function delete($id) {
		if (rand(0, 1)) {
			echo "Запись №$id удалена";
		}
		else {
			header("HTTP/1.1 500 Bad DB connect");
		}
	}
?>