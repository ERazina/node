<?php
	$url  = $_REQUEST['_url'];
	$id   = $_REQUEST['id'];
	$path = pathinfo($url);
	
	if (file_exists("{$path['dirname']}/{$path['filename']}.php")) {
		include_once "{$path['dirname']}/{$path['filename']}.php";
	}
	else {
		header('HTTP/1.1 404 Page not found!');
	}
?>