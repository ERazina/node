﻿<?php	
	$client   = new SoapClient("http://localhost/web-service/server.wsdl");
	$arrMet   = $client->__getFunctions();
	echo '<h3>Доступные методы</h3>';
	echo '<pre>';
	print_r($arrMet);
	echo '</pre>';
	echo '<hr/>';
	$users    = json_decode($client->getUserList());
	echo '<h3>Пользователи</h3>';
	echo '<pre>';
	print_r($users);
	echo '</pre>';
	echo '<hr/>';
?>