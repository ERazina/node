<?php
	class Model_user {
		public static function createUser ($name, $key, $id) {
			$apps = self::getApps($name, $key);
			if ($apps) {
				if (self::checkUser($apps, $id)) {
					$hash = getHash();
					$data = array('id_apps' => $apps, 'id_user' => $id, 'token' => $hash);
					Controller_DB::insert('users', $data);
					return array('error' => 0, 'text' => 'Пользователь создан!', 'token' => $hash);
				}
				else {
					return array('error' => 4, 'text' => 'Такой пользователь уже существует!');
				}
			}
			else {
				return array('error' => 3, 'text' => 'Связка name/key некорректная!');
			}
		}
		
		public static function getApps($name, $key) {
			$cols  = array('id_apps' => 'id');
			$where = array('name' => $name, 'key' => $key);
			$apps  = Controller_DB::getObject('apps', $cols, $where);
			
			return empty($apps) ? false : $apps[0]->id;
		}
		
		public static function checkUser($apps, $id) {
			$cols  = array('id' => 'id');
			$where = array('id_apps' => $apps, 'id_user' => $id);
			$info  = Controller_DB::getObject('users', $cols, $where);
			return empty($info) ? TRUE : FALSE;
		}
		
		public static function getToken($name, $key, $id) {
			$apps = self::getApps($name, $key);
			if ($apps) {
				if (!self::checkUser($apps, $id)) {
					$hash  = getHash();
					$data  = array('token' => $hash);
					$where = array('id_apps' => $apps, 'id_user' => $id);
					Controller_DB::update('users', $data, $where);
					return array('error' => 0, 'text' => 'Токен обновлен', 'token' => $hash);
				}
				else {
					return array('error' => 4, 'text' => 'Такой пользователь не существует!');
				}
			}
			else {
				return array('error' => 3, 'text' => 'Связка name/key некорректная!');
			}
		}
	}
?>