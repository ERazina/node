<?php
	// Подключаем конфиг файл и функции
	include_once 'config.php';
	include_once 'function.php';
	// описываем механизм подключения классов
	function __autoload($class) {
		$class = explode('_', $class);
		$path  = '.';
		for ($i = 0, $cnt = count($class); $i < $cnt; $i++) {
			$path.= '/' . $class[$i];
		}
		$path.= '.php';
		if (file_exists($path)) {
			include_once $path;
		}
		else {
			echo 'Запрашиваемая страница отсутствует!';
		}
	}
	// Запускаем класс-маршрутизатор
	Controller_route::start($_SERVER['REQUEST_URI']);
?>