<?php
	// Класс заглушка на 
	class Controller_index {
		public static function start() {
			header('HTTP/1.1 404 PAGE NOT FOUND');
		}
	}
?>