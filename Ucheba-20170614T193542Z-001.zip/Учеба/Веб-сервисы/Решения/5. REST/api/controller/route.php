<?php
	class Controller_route {
		public static function start($url) {
			$url   = trim(str_replace(trim(BASE, '/'), '', trim($url, '/')), '/');
			$info  = explode('/', $url);
			$class = 'Controller_' . ($info[0] ? $info[0] : 'index');
			$id    = isset($info[1]) ? (int)$info[1] : 0;
			$class::start($id);
		}
	}
?>