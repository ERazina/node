<?php
	/*
		Контроллер для работы с пользователем
		Содержит методы
			start: распределяет пользователей по дальнейшим методам
			create: создает нового пользователя, а заодно и выписывает ему token
			getToken: выписывает пользователю токен для работы
	*/
	class Controller_user extends Controller_base {
		public static function start($id) {
			$method = $_SERVER['REQUEST_METHOD'];
			switch ($method) {
				case 'PUT':
					self::getToken($id);
					break;
				case 'POST':
					self::create($id);
					break;
				case 'GET': case 'DELETE':
					echo json_encode(array('error' => 1, 'text' => "Метод $method в данном разделе не поддерживается!"));
					break;
				default: 
					echo json_encode(array('error' => 1, 'text' => "Неизвестный метод $method!"));
			}
		}
		public static function create($id) {
			$name = $_POST['name'];
			$key  = $_POST['key'];
			if ($id > 0) {
				echo json_encode(Model_user::createUser($name, $key, $id));
			}
			else {
				echo json_encode(array('error' => 2, 'text' => 'Для корректной работы необходимо передать id пользователя'));
			}
		}
		
		public static function getToken($id) {
			if ($id > 0) {
				$data = json_decode(file_get_contents('php://input'));
				echo json_encode(Model_user::getToken($data->name, $data->key, $id));
			}
			else {
				echo json_encode(array('error' => 2, 'text' => 'Для корректной работы необходимо передать id пользователя'));
			}
		}
	}
?>