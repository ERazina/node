<?php
	// Описываем путь до своего проекта
	define('BASE', 'api/');
	// Описываем настройки подключения к базе
	define('HOST', 'localhost');
	define('USER', 'root');
	define('PASS', '');
	define('DB',   'api');
?>