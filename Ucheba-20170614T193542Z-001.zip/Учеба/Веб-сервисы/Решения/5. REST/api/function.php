<?php
	function getHash($size = 32) {
		$abc = 'abcsefghijklmnopqrstuvwxyz0123456789';
		$str = '';
		for ($i = 0; $i < $size; $i++) {
			$str.= $abc[rand(0, strlen($abc) - 1)];
		}
		return $str;
	}
?>