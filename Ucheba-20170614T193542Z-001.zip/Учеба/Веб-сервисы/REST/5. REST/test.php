<?php
	$name = 'test';
	$key  = 'bestkey';
	
	// Пример регистрации пользователя
	
	$ch = curl_init("http://localhost/api/user/1/");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($ch, CURLOPT_POST, TRUE);
	curl_setopt($ch, CURLOPT_POSTFIELDS, "name=$name&key=$key");
	$answer = (array)json_decode(curl_exec($ch));
	curl_close($ch);
	if ($answer['error']) {
		echo $answer['text'];
	}
	else {
		echo 'token ' . $answer['token'];
	}
	
	
	// Пример обновления токена
	
	$ch = curl_init("http://localhost/api/user/1");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($ch, CURLOPT_CUSTOMREQUEST , 'PUT');
	curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode(array("name" => $name, "key" => $key)));
	$answer = (array)json_decode(curl_exec($ch));
	curl_close($ch);
	if ($answer['error']) {
		echo $answer['text'];
	}
	else {
		echo 'token ' . $answer['token'];
	}
	
?>