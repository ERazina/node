<?php
class Server {
    
    //Метод для получения общей ингформации
    public function getInfo(){
        $db = mysqli_connect('localhost', 'root', '', 'order');
        mysqli_set_charset($db, 'utf-8');
        $query = '
            SELECT 
                SUM(`recommended` + `typical`) AS `sum`,
                COUNT(`id`) AS `order_cnt`,
                COUNT(DISTINCT `user_id`) AS `user_cnt`,
                SUM(`recommended`) AS `recommended`,
                SUM(`typical`) AS `typical`
            FROM `order`;
            ';

        $result = mysqli_query($db, $query);
        $response = mysqli_fetch_assoc($result);
        return json_encode($response);
    }
    
    public function getUser($prodId){
        $db = mysqli_connect('localhost', 'root', '', 'order');
        mysqli_set_charset($db, 'utf-8');
        $query='
       SELECT `user`.`id`,`name`,`surname` FROM `order`
       LEFT JOIN `user` ON `user`.`id`=`order`.`user_id`
       WHERE `product_id` = ' . $prodId . ';
       ';
         $result = mysqli_query($db, $query);
        $user = mysqli_fetch_all($result);
        return json_encode($user);
    }
    
    public function getProduct($userId){
        $db = mysqli_connect('localhost', 'root', '', 'order');
        mysqli_set_charset($db, 'utf-8');
        $query='
       SELECT `order`.`id`,`order`.`product_id`,`product`.`name` FROM `order`
       LEFT JOIN `user` ON `user`.`id`=`order`.`user_id`
       LEFT JOIN `product` ON `product`.`id`=`order`.`product_id`
       WHERE `user`.`id` = ' . $userId . ';
       ';
         $result = mysqli_query($db, $query);
        $user = mysqli_fetch_all($result);
        return json_encode($user);
    }
    
    public function getAllProducts(){
        $db = mysqli_connect('localhost', 'root', '', 'order');
        mysqli_set_charset($db, 'utf-8');
        $query='
        SELECT `id`,`name` FROM `product`';
         $result = mysqli_query($db, $query);
        $response = mysqli_fetch_all($result);
        return json_encode($response);
    }
    
    public function getAllUsers(){
        $db = mysqli_connect('localhost', 'root', '', 'order');
        mysqli_set_charset($db, 'utf-8');
        $query='
       SELECT `id`,`name`,`surname` FROM `user`';
         $result = mysqli_query($db, $query);
        $response = mysqli_fetch_all($result);
        return json_encode($response);
    }
}


//Выключение кэширования
    ini_set("soap.wsdl_cache_enabled", "0");
	
	$url = "http://localhost/SOAP/server.wsdl";
	
	$server = new SoapServer($url);	//путь до wsdl-файла
	$server->setClass("Server");	// используемый класс
	$server->handle();				// запуск сервиса

?>
