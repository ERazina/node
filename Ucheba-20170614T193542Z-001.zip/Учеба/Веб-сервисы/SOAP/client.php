<?php
	// создаем soap клиент. ссылку делаем на wsdl. Именно оттуда мы получим описание доступных функций, переменных и их типов.	
	$client = new SoapClient("http://localhost/soap/server.wsdl");
//Получаем список доступных методов с их описанием
$arrMet= $client->__getFunctions();
//Запрашиваем общую информацию
$info = json_decode($client->getInfo());
$user = json_decode($client->getUser());
$allProducts = json_decode($client->getAllProducts());
$allUsers = json_decode($client->getAllUsers());
$getProduct = json_decode($client->getProduct());
	echo '<pre>';
	print_r($getProduct);
	echo '<pre>';
?>