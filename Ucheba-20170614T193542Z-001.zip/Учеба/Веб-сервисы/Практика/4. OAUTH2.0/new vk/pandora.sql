-- phpMyAdmin SQL Dump
-- version 4.1.7
-- http://www.phpmyadmin.net
--
-- Хост: localhost
-- Время создания: Июн 10 2014 г., 16:41
-- Версия сервера: 5.1.63
-- Версия PHP: 5.4.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- База данных: `customweb`
--

-- --------------------------------------------------------

--
-- Структура таблицы `pandora`
--

CREATE TABLE IF NOT EXISTS `pandora` (
  `pandora_id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'идентификатор',
  `pandora_uid` bigint(11) NOT NULL COMMENT 'id пользователя',
  `pandora_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL COMMENT 'имя пользователя',
  `pandora_app_id` bigint(11) NOT NULL COMMENT 'id приложения',
  `pandora_gid` bigint(11) DEFAULT NULL COMMENT 'id группы',
  `pandora_app_secret` text COLLATE utf8_unicode_ci NOT NULL COMMENT 'уникальный код приложения',
  `pandora_access_token` text COLLATE utf8_unicode_ci NOT NULL COMMENT 'уникальный token',
  `pandora_access_secret` text COLLATE utf8_unicode_ci NOT NULL COMMENT 'уникальный secret',
  PRIMARY KEY (`pandora_id`),
  UNIQUE KEY `pandora_uid` (`pandora_uid`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
