
/*
|--------------------------------------------------------------------------
| 	Подключить скрипт, если есть селектор на странице
|--------------------------------------------------------------------------
*/
function appendScr(script_rt, selector){
	"use strict";
	if ( typeof script_rt !== "undefined" && script_rt &&  typeof selector !== "undefined" && selector) {
		 if($(selector).length){
         	var script = document.createElement("script");
        	script.type = "text/javascript";
        	script.src = script_rt;
        	document.body.appendChild(script);
			
    	}
	} 
}
/*
|--------------------------------------------------------------------------
| 	Подключить стили, если есть селектор на странице
|--------------------------------------------------------------------------
*/
function appendCss(route, selector){
	"use strict";
	if ( typeof route !== "undefined" && route &&  typeof selector !== "undefined" && selector) {
		 if($(selector).length){
         	var stylesheet = document.createElement("link");
        	stylesheet.type = "text/css";
        	stylesheet.href = route;
			stylesheet.rel = "stylesheet;"
        	document.head.appendChild(stylesheet);
    	}
	} 
}
// JavaScript Document