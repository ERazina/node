<?php
date_default_timezone_set('Europe/Moscow');
define('HOST', "localhost");
define('USER', "");
define('PASSWORD', "");
define('DBNAME', "");

function no_cache() {
  header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");
  header("Cache-Control: no-cache, must-revalidate");
  header("Pragma: no-cache");
  header("Last-Modified: ".date("D, d M Y H:i:s")." GMT");
}

function call_db($host, $user, $password, $dbname){
	$db = mysqli_connect($host, $user, $password);
	mysqli_select_db($db, $dbname);
	mysqli_query($db,"set names 'utf8'");
	return $db;
}

function select_markers()
{
	
}

$db = call_db(HOST, USER, PASSWORD, DBNAME);
select_markers();

?>