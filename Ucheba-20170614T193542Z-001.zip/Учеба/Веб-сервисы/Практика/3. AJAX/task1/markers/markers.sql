--
-- Структура таблицы `marker_type`
--

CREATE TABLE IF NOT EXISTS `marker_type` (
  `marker_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `marker_type_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `marker_type_acronym` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`marker_type_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `marker_type`
--

INSERT INTO `marker_type` (`marker_type_id`, `marker_type_name`, `marker_type_acronym`) VALUES
(1, 'адрес', 'address'),
(2, 'другой', 'other');
--
-- Структура таблицы `marker`
--

CREATE TABLE IF NOT EXISTS `marker` (
  `marker_id` int(11) NOT NULL AUTO_INCREMENT,
  `marker_marker_type_id` int(11) DEFAULT NULL,
  `marker_latitude` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `marker_longitude` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `marker_size_x` int(11) DEFAULT NULL,
  `marker_size_y` int(11) DEFAULT NULL,
  `marker_point1_x` int(11) DEFAULT NULL,
  `marker_point1_y` int(11) DEFAULT NULL,
  `marker_point2_x` int(11) DEFAULT NULL,
  `marker_point2_y` int(11) DEFAULT NULL,
  `marker_title_ru` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `marker_title_en` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `marker_title_kor` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `marker_content_ru` text COLLATE utf8_unicode_ci,
  `marker_content_en` text COLLATE utf8_unicode_ci,
  `marker_content_kor` text COLLATE utf8_unicode_ci,
  `marker_adress` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `marker_image` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`marker_id`),
  KEY `FK_Reference_7` (`marker_marker_type_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `marker`
--

INSERT INTO `marker` (`marker_id`, `marker_marker_type_id`, `marker_latitude`, `marker_longitude`, `marker_size_x`, `marker_size_y`, `marker_point1_x`, `marker_point1_y`, `marker_point2_x`, `marker_point2_y`, `marker_title_ru`, `marker_title_en`, `marker_title_kor`, `marker_content_ru`, `marker_content_en`, `marker_content_kor`, `marker_adress`, `marker_image`) VALUES
(1, 1, '60.00487160586939', '30.348308591486784', 25, 41, 0, 0, 13, 41, 'Покров', 'Pokrov', NULL, '&lt;p&gt;«Покров»&lt;br /&gt;\r\nМалая Объездная улица, 22 корпус 2, &lt;br /&gt;\r\nСанкт-Петербург, Россия, 194223&lt;/p&gt;', '&lt;p&gt;«Покров»&lt;/p&gt;\r\n\r\n&lt;p&gt;Малая Объездная улица, 22 корпус 2, Санкт-Петербург, Россия, 194223&lt;/p&gt;', NULL, 'Малая Объездная улица, 22 корпус 2, Санкт-Петербург, Россия, 194223', 'img/mark.png');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
