function init_gmap() {
    //set map center
    var mapLat = 59.93601178734096; //set latitude - get lat/long @ http://universimmedia.pagesperso-orange.fr/geo/loc.htm
    var mapLng = 30.32291069626808; //set longitude
    var mapZoomLevel = 16; //initial map zoom level
    //main marker info
    var mapControl = true; //map combobox - allowing to switch between plan, satellite, + relief
	var marker={
	latitude:mapLat,
	longitude:mapLng,
	size_x:45,//ширина иконки
	size_y:36,//высота иконки
	point1_x:148,//координата в спрайте
	point1_y:529,//коордиата в спрайте
	point2_x:23,//место в самой картинке
	point2_y:36,//место в самой картинке
	img:'img/marker_sprite.png',
	title:'Заголовок карты',
	content:'<strong>Описание маркера на карте</strong>'
	};


    //CREATE MAP ----------------------------------------------------------------------
    var latlng = new google.maps.LatLng(mapLat, mapLng);
    var settings = {
        zoom: mapZoomLevel,
        center: latlng,
        mapTypeControl: mapControl,
        streetViewControl: true,
        panControl: true,
        scrollwheel: false,
        rotateControl: true,
        overviewMapControl: true,
        mapTypeControlOptions: {
            style: google.maps.MapTypeControlStyle.DEFAULT
        },
        navigationControlOptions: {
            style: google.maps.NavigationControlStyle.SMALL
        },
        mapTypeId: google.maps.MapTypeId.HYBRID
    };
    var map = new google.maps.Map(document.getElementById("map_canvas"), settings);
    var stylez = [
  {
    "featureType": "water",
    "stylers": [
      { "color": "#8a9ed4" },
      { "hue": "#ff3c00" }
    ]
  },{
  }
];

    var styledMapOptions = {
        name: "Grayscale"
    };
    var gsMapType = new google.maps.StyledMapType(stylez, styledMapOptions);
    map.mapTypes.set('grayscale', gsMapType);
    map.setMapTypeId('grayscale');

                var valmark = new google.maps.Marker({
                    position: new google.maps.LatLng(marker.latitude, marker.longitude),
                    map: map,
                    icon: new google.maps.MarkerImage(marker.img,
                        new google.maps.Size(marker.size_x, marker.size_y),
                        new google.maps.Point(marker.point1_x, marker.point1_y),
                        new google.maps.Point(marker.point2_x, marker.point2_y)
                    ),
                    animation: google.maps.Animation.BOUNCE, //or DROP
                    title: marker.title
                });
                var infowindow = new google.maps.InfoWindow({
                    content: marker.content
                });
                google.maps.event.addListener(valmark, 'click', function() {
                    infowindow.open(map, valmark);
                });
                map.setCenter(valmark.position);
               $(window).resize(function() {
                   map.setCenter(valmark.position);
               });

}// JavaScript Document