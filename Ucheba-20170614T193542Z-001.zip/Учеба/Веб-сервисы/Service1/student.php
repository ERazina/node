<?php
   
    $xml=simplexml_load_file('students.xml');

    $query = 'INSERT INTO `student` (`id`,`first`,`last`,`patronymic`,`math`,`russian`,`informatics`,`total`,`advantage`) VALUES ';
        foreach($xml->student as $student) {
        $query.= '(';
        $query.= $student['id'] . ',';
        $query.='"' . $student->name->first .'", ';
        $query.='"' . $student->name->last .'", ';
        $query.='"' . $student->name->patronymic .'", '; 
        $query.='"' . $student->score->math .'", ';
        $query.='"' . $student->score->russian .'", ';
        $query.='"' . $student->score->informatics .'", ';
        $query.='"' . $student->score['total'] .'", '; 
        $query.='"' . $student->advantage .'"';
        $query.='), ';
    }
    $query = trim($query, ', ');
echo $query;
    $db = mysqli_connect('localhost', 'root', '', 'students');
    mysqli_set_charset($db, 'utf8');
    mysqli_query($db, $query);
echo mysqli_error($db);
//    echo $query;
?>

